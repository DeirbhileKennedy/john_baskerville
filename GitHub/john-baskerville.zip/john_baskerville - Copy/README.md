IXD101 Interaction design fundmentals 
=====================================

John Baskerville
----------------

- [john baskerville 03 - markup](https://deirbhilekennedy.github.io/baskerville3.html)